select * from cereal

--top 10 products by rating
SELECT TOP(10) name,rating
FROM cereal
ORDER BY rating DESC;

--bottom 10 products by rating
SELECT TOP(10) name,rating
FROM cereal
ORDER BY rating ASC;
